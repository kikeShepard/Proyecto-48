# Globo aerostático etapa 4
## Enlace de referencia 1 para la clase PROC48.
  
18-01-2022  
También usado en PROC52 1:4 Referencia de la maestra 4.  
Actividad adicional - Globo aerostático III
